Scott Polmanteer
sjp94

Jon-Paul Kasper
jk1457

run on linux using this command for the given test file

	team19_project1.py -i "test2_bin.txt" -o "team19_out"


run on linux general
	team19_project1.py -i "TEST_FILE" -o "OUTPUT_FILE"

